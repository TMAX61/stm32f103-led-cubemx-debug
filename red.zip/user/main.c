#include <stm32f10x.h>
#include <Delay.h>
#include <OLED.h>
#include <count.h>

int main(void)
{
	OLED_Init ();
	count_Init ();
	OLED_ShowString (1,1,"COUNT:");
	while(1)
	{
		OLED_ShowNum(1,7,count_get() ,5);
		
	}
	


}
