#ifndef __COUNT__H
#define __COUNT__H

void count_Init(void);	
uint16_t count_get(void);

#endif
