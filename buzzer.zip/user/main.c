#include <stm32f10x.h>
#include <OLED.h>
#include <Timer.h>
#include <Key.h>
#include <Buzzer.h>


volatile uint16_t Num = 0;      
volatile uint8_t  Run = 0;      

int main(void)
{

    Timer_Init();
    OLED_Init();
    Key_Init();
	Buzzer_Init ();
    OLED_ShowString(1, 1, "Time");
    GPIO_SetBits (GPIOB,GPIO_Pin_12 );
    while (1)
    {
        if (Key_GetNum()) { Num = 0; Run = 1; Buzzer_OFF(); }

        OLED_ShowNum(1, 4, Num, 2);
    }
}

void TIM2_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
    {
        if (Run) { Num++; if (Num >= 5) { Num = 5; Run = 0; Buzzer_ON(); } }
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    }
}
