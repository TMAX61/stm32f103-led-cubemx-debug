#ifndef __ENCODER__H
#define __ENCODER__H

void  ENCODER_Init(void);
int16_t ENCODER_get(void);
	
#endif
