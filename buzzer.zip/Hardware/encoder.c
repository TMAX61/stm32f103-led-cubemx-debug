#include "stm32f10x.h" 

int16_t ENCODER_counter;
void  ENCODER_Init(void)
{
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOB,ENABLE );
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_AFIO,ENABLE );
	
	GPIO_InitTypeDef GPIO_Initstructure;
	GPIO_Initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Initstructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_0 ;
	GPIO_Initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init (GPIOB,&GPIO_Initstructure );

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource0);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource1);
	
	EXTI_InitTypeDef EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line1 | EXTI_Line0  ;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE ;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt ;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_Init(&EXTI_InitStructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC0_InitStucture;
	NVIC0_InitStucture.NVIC_IRQChannel = EXTI0_IRQn;
	NVIC0_InitStucture.NVIC_IRQChannelCmd = ENABLE ;
	NVIC0_InitStucture.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC0_InitStucture.NVIC_IRQChannelSubPriority =1;
	NVIC_Init(&NVIC0_InitStucture);
	
	NVIC_InitTypeDef NVIC1_InitStucture;
	NVIC1_InitStucture.NVIC_IRQChannel = EXTI1_IRQn;
	NVIC1_InitStucture.NVIC_IRQChannelCmd = ENABLE ;
	NVIC1_InitStucture.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC1_InitStucture.NVIC_IRQChannelSubPriority =2;
	NVIC_Init(&NVIC1_InitStucture);

}

int16_t ENCODER_get(void)
{
	int16_t Temp;
	Temp = ENCODER_counter ; 
	ENCODER_counter =0;
	return Temp   ;

}

void EXTI1_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line1)==SET )
	{
	    if(GPIO_ReadInputDataBit (GPIOB,GPIO_Pin_0 )==0)
		{
			ENCODER_counter  ++;
		}
	EXTI_ClearITPendingBit (EXTI_Line1 );
	}
	
}

void EXTI0_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line0 ) == SET )
	{
	     if(GPIO_ReadInputDataBit (GPIOB,GPIO_Pin_1)==0)
		 {
			 ENCODER_counter  -- ;
			 
		 }
		 EXTI_ClearITPendingBit (EXTI_Line0 );
	
	}
	
}
